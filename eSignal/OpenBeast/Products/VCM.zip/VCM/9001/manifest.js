F2_jsonpCallback_9001({ 
  "scripts": [ 
 "Products/VCM/9001/appclass.js"
 ],
  "styles": [
 "Products/VCM/9001/app.css"
  ],
 "apps": [{
 "data": {},
 "html": ['<div><table class="tblClass hdrBorder table table-condensed" id="9001"><thead></thead><tbody><tr></tr><tr><td>First String</td><td><input id="9001_1" type="text" value="First String" /></td></tr><tr><td>Second String</td><td><input id="9001_2" type="text" value="Second String" /></td></tr><tr><td><input id="9001_3" type="text" /></td></tr></tbody></table></div>'].join("")
 }]
})
  
 