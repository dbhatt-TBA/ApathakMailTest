F2_jsonpCallback_BYC0152({ 
  "scripts": [ 
 "Products/VCM/BYC0152/appclass.js"
 ],
  "styles": [
 "Products/VCM/BYC0152/app.css"
  ],
 "apps": [{
 "data": {},
 "html": ['<div><table class="tblClass hdrBorder table table-condensed" id="BYC0152"><thead></thead><tbody><tr><td colspan="5"><div class="productNameHdr pull-left"><div  style="float: left; margin-left: 10px;"><strong>Bond Yield Calculator</strong></div></div></td></tr><tr><td colspan="5"><div class="ServerName" style="text-align: left !important;"></div></td></tr><tr><td><input id="BYC0152_99999992" type="text" /></td></tr><tr><td><input id="BYC0152_4" type="button" value="Details" /></td><td><select id="BYC0152_100000002"></select></td><td></td></tr><tr><td>Currency</td><td><select id="BYC0152_1"></select></td></tr><tr><td>Selection</td><td><select id="BYC0152_100"></select></td></tr><tr><td>Bd/Yld Type</td><td><select id="BYC0152_150"></select></td><td>Yield Type</td><td><select id="BYC0152_200"></select></td></tr><tr><td>Cpn/Mat</td><td><input id="BYC0152_250" type="text" /></td><td>Maturity</td><td><input id="BYC0152_300" type="text" title="datepick" /></td></tr><tr><td><select id="BYC0152_5"></select></td></tr><tr><td>Bid</td><td>Ask</td></tr><tr><td>Price</td><td><input id="BYC0152_1000" type="text" /></td><td><input id="BYC0152_1001" type="text" /></td></tr><tr><td><select id="BYC0152_3"></select></td><td>Yield</td><td><input id="BYC0152_1100" type="text" /></td><td><input id="BYC0152_1101" type="text" /></td></tr><tr><td>Duration</td><td><input id="BYC0152_1200" type="text" /></td><td><input id="BYC0152_1201" type="text" /></td></tr><tr><td>Mod. Dur.</td><td><input id="BYC0152_1300" type="text" /></td><td><input id="BYC0152_1301" type="text" /></td></tr><tr><td>$ Duration</td><td><input id="BYC0152_1400" type="text" /></td><td><input id="BYC0152_1401" type="text" /></td></tr><tr><td>Convexity</td><td><input id="BYC0152_1500" type="text" /></td><td><input id="BYC0152_1501" type="text" /></td></tr><tr><td>$ Cvx</td><td><input id="BYC0152_1600" type="text" /></td><td><input id="BYC0152_1601" type="text" /></td></tr><tr><td>PVBP</td><td><input id="BYC0152_1700" type="text" /></td><td><input id="BYC0152_1701" type="text" /></td></tr><tr><td>YV</td><td><select id="BYC0152_2000"></select></td><td><input id="BYC0152_1800" type="text" /></td><td><input id="BYC0152_1801" type="text" /></td></tr><tr><td><input id="BYC0152_6" type="button" value="\=> CTD Bond Selection" /></td></tr></tbody></table></div>'].join("")
 }]
})
  
 