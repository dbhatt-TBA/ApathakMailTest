F2_jsonpCallback_GD8839({ 
  "scripts": [ 
 "Products/VCM/GD8839/appclass.js"
 ],
  "styles": [
 "Products/VCM/GD8839/app.css"
  ],
 "apps": [{
 "data": {},
 "html": ['<div><table class="tblClass hdrBorder table table-condensed" id="GD8839"><thead></thead><tbody><tr><td colspan="11"><div class="productNameHdr pull-left"><div  style="float: left; margin-left: 10px;"><strong>GridView Design</strong></div></div></td></tr><tr><td colspan="11"><div class="ServerName" style="text-align: left !important;"></div></td></tr><tr></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr><tr><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td><td>Kiran</td></tr></tbody></table></div>'].join("")
 }]
})
  
 