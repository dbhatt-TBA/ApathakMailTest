F2_jsonpCallback_RDV0060({ 
  "scripts": [ 
 "Products/VCM/RDV0060/appclass.js"
 ],
  "styles": [
 "Products/VCM/RDV0060/app.css"
  ],
 "apps": [{
 "data": {},
 "html": ['<div><table class="tblClass hdrBorder table table-condensed" id="RDV0060"><thead></thead><tbody><tr><td colspan="8"><div class="productNameHdr pull-left"><div  style="float: left; margin-left: 10px;"><strong>Realtime Data Viewer</strong></div></div></td></tr><tr><td colspan="8"><div class="ServerName" style="text-align: left !important;"></div></td></tr><tr></tr><tr><td><input id="RDV0060_39" type="button" value="Instrument Components" /></td></tr><tr><td>Funny Name</td><td><input id="RDV0060_1" type="text" value="Funny Name" /></td><td><input id="RDV0060_7" type="text" /></td><td><select id="RDV0060_2"></select></td><td>Show</td><td><select id="RDV0060_3"></select></td><td>Timestamp</td><td><select id="RDV0060_4"></select></td></tr><tr><td></td></tr></tbody></table></div>'].join("")
 }]
})
  
 