F2_jsonpCallback_SS29001({ 
  "scripts": [ 
 "Products/VCM/SS29001/appclass.js"
 ],
  "styles": [
 "Products/VCM/SS29001/app.css"
  ],
 "apps": [{
 "data": {},
 "html": ['<div><table class="tblClass hdrBorder table table-condensed" id="SS29001"><thead></thead><tbody><tr><td colspan="2"><div class="productNameHdr pull-left"><div  style="float: left; margin-left: 10px;"><strong>SDK SAMPLE 2</strong></div></div></td></tr><tr><td colspan="2"><div class="ServerName" style="text-align: left !important;"></div></td></tr><tr></tr><tr><td>First String</td><td><input id="SS29001_1" type="text" value="First String" /></td></tr><tr><td>Second String</td><td><input id="SS29001_2" type="text" value="Second String" /></td></tr><tr><td><input id="SS29001_3" type="text" /></td></tr></tbody></table></div>'].join("")
 }]
})
  
 